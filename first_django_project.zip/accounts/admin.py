from django.contrib import admin
from .models import CustumUser

# Register your models here.

admin.site.register(CustumUser)