from django.contrib import admin
from .models import *



admin.site.register(AdvertisModel)

# Register your models here.
